let hunger = 100;
let happiness = 10;
let energy = 100;
function feed(){
    console.log("Feed Function")
    hunger-=20;
    if(hunger<=0){
        hunger=0;
    }else{
        happiness+=20;
    }
    displayInfo();
}
function pet(){
    console.log("Pet Function")
    if(happiness<100){
        happiness+=10;
    }
    displayInfo();
}
function play(){
    //increase happiness and decrease energy
    if(happiness<100){
      happiness+=10;
      energy-=10;  
    }else if(happiness == 100 && energy > 0 ){
        energy-=10;  
    }
    displayInfo();

    
}

function displayInfo(){
    document.getElementById("hungerPoints").innerHTML=hunger;
    document.getElementById("happinessPoints").innerHTML=happiness;
    document.getElementById("energyPoints").innerHTML=energy;
}
displayInfo();